// script.js (pode ser usado para adicionar interatividade futura)
console.log("Portfólio Grécia carregado!");

